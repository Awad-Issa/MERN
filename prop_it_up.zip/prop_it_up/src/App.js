import './App.css';
import PersonCard from "./components/PersonCard";

function App() {
  return (

      <>

          <PersonCard firstName={"Awad"} lastName={"Issa"} age={22} hairColor={"yellow"}/>
          <PersonCard firstName={"Oday"} lastName={"iseed"} age={18} hairColor={"yellow"}/>
          <PersonCard firstName={"Hoda"} lastName={"Attiyeh"} age={27} hairColor={"yellow"}/>


      </>

  );
}

export default App;
